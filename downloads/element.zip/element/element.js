window.onload = function(){

$("#modalclose").click(function(){
  $(".modal-container").hide();
});

$("#modalshow").click(function(){
  $(".modal-container").show();
});
}
